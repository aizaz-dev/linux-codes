import React from "react";
import "./SelfPlay.scss"
const SelfPlay = () => {
  return <div>SelfPlay</div>;
};

export default SelfPlay;
