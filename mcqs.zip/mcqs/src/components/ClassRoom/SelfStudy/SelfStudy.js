import React from "react";
import "./SelfStudy.scss";
const SelfStudy = () => {
  return <div>SelfStudy</div>;
};

export default SelfStudy;
