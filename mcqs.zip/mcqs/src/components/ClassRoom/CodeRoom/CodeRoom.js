import React from "react";
import "./CodeRoom.scss";
const CodeRoom = () => {
  return <div>CodeRoom</div>;
};

export default CodeRoom;
