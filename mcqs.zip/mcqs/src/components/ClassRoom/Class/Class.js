import React from "react";
import "./Class.scss";
const Class = () => {
  return <div>Class</div>;
};

export default Class;
