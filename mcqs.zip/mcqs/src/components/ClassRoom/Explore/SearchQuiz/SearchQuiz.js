import React from "react";

const SearchQuiz = () => {
  return <div>SearchQuiz</div>;
};

export default SearchQuiz;
