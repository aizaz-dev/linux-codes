import React from 'react'

const CreateQuiz = () => {
  return (
    <div>CreateQuiz</div>
  )
}

export default CreateQuiz